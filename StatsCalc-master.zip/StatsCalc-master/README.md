# StatsCalc

By: Paul Kim & Raj Patel 
