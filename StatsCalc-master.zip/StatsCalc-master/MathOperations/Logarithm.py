import math
class Logarithm:

    @staticmethod
    def log(logstart, logend):
        return math.log(logstart, logend)