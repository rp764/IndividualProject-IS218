class Subtraction:



    @staticmethod
    def difference(minuend, subtraend):
        return minuend - subtraend