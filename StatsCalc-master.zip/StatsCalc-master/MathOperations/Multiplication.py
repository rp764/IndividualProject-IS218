class Multiplication:



    @staticmethod
    def multiply(multstart, multend):
        return multstart * multend