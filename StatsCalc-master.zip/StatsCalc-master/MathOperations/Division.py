class Division:

    @staticmethod
    def divide(divstart, divend):
        return divstart / divend