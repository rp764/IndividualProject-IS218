class Root:

    def __init__(self):
        pass

    @staticmethod
    def root(rootstart, rootend):
        return rootstart ** (1.0/rootend)