class Exponentiation:

    @staticmethod
    def exponent(expstart, expend):
        return expstart ** expend